package com.example.login_2023.presentation.login.screens

import android.annotation.SuppressLint
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.login_2023.R
import com.example.login_2023.presentation.login.navigation.Destinations


@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun HomeScreen(navController: NavController, user: String) {
    Scaffold(
        topBar = {
            TopAppBar() {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = "¡DATOS DEL LOG IN!", fontSize = 25.sp)
                    Spacer(modifier = Modifier.width(20.dp))
                }
            }
        },
        bottomBar = {
            BottomAppBar() {
                Row(
                    modifier = Modifier.fillMaxSize(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.ExitToApp,
                        contentDescription = "",
                        modifier = Modifier.clickable {
                            navController.navigate(route = Destinations.RegistrationScreen.route)
                        })
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = "EXIT", fontSize = 25.sp)
                    Spacer(modifier = Modifier.width(20.dp))
                }
            }
        }
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        )
        {
            Row(modifier = Modifier.padding(8.dp)) {
                Image(
                    modifier = Modifier
                        .size(100.dp)
                        .clip(CircleShape)
                        .border(1.5.dp, MaterialTheme.colors.secondaryVariant, CircleShape),
                    contentDescription = "ICONO",
                    painter = painterResource(R.drawable.icono2)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column() {
                    Text(
                        text = "$user",
                        fontSize = 20.sp,
                        color = MaterialTheme.colors.primary,
                        style = MaterialTheme.typography.button
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                }
            }
        }
    }
}